package hwbackend02_구미_3반_지민우;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/regist.do")
public class RegistProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String info = request.getParameter("info");
		ProductDto product = new ProductDto();
		product.setProductName(name);
		product.setPrice(price);
		product.setProductInfo(info);
		System.out.println(name);
		System.out.println(price);
		System.out.println(info);
		ProductDAO dao = new ProductDAOImpl();
		int cnt = 0;
		int no = 0;
		try {
			cnt = dao.insertProduct(product);
			no = dao.selectProductNo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		product.setProductNo(no);
		if(cnt != 0) {
			request.setAttribute("product", product);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/product/registsuccess.jsp");
			dispatcher.forward(request, response);
		}else {
			response.sendRedirect("/hwbackend02_구미_3반_지민우/product/registfail.jsp");
		}
		
	}

}
