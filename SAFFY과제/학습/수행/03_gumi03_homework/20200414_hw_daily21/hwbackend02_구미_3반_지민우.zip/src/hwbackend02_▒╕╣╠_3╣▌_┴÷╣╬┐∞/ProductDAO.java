package hwbackend02_구미_3반_지민우;

public interface ProductDAO {
	int insertProduct(ProductDto product)throws Exception;
	int selectProductNo()throws Exception;
}
