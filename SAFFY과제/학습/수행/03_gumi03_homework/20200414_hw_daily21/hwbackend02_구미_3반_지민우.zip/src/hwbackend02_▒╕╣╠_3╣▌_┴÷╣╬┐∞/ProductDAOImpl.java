package hwbackend02_구미_3반_지민우;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import common.db.ConnectionFactory;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public int insertProduct(ProductDto product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int cnt = 0;
		try {
			conn = ConnectionFactory.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product ( 		      ");
			sql.append("		product_name, price, product_info ");
			sql.append(") values ( 						  ");
			sql.append(" 	?,?,? 						  ");
			sql.append(")								  ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, product.getProductName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getProductInfo());
			cnt = pstmt.executeUpdate();
		} finally {
			ConnectionFactory.close(pstmt, conn);
		}
		return cnt;
	}

	@Override
	public int selectProductNo() throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int no = 0;
		try {
			conn = ConnectionFactory.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select max(product_no) " + 
					"from product");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				no = rs.getInt("max(product_no)");
				System.out.println(no);
			}
		} finally {
			rs.close();
			ConnectionFactory.close(pstmt, conn);
		}
		return no;
	}

}
