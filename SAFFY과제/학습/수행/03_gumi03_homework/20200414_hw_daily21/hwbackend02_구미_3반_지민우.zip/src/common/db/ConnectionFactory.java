package common.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ConnectionFactory {
	// 연결작업 처리하기
	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		return  DriverManager.getConnection(
				"jdbc:mysql://127.0.0.1:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8",
				"ssafy",
				"ssafy"
		);
	}
	public static void close(PreparedStatement stmt, Connection con) {
		try {
			if(stmt != null)
				stmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			};
		try {
			if(con != null)
				con.close();
			} catch(Exception e) {
				e.printStackTrace();
			};
	}
}
