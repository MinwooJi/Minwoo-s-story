create database ssafyweb;
use ssafyweb;
-- drop table product;
create table product(
	product_no int auto_increment primary key,
    product_name varchar(30) not null,
    price int check(price>0),
    product_info varchar(50),
    reg_date TIMESTAMP NOT NULL DEFAULT current_timestamp
);


insert into product(product_name,price,product_info) values('김삿갓',111,'1');