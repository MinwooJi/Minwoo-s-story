export default {
  template: `
    <div>
        삭제중...
    </div>
    `,
  created() {
    const params = new URL(document.location).searchParams;
    const empls = JSON.parse(localStorage.getItem('ssafyemp'));
    empls.empls = empls.empls.filter((emp) => emp.id != params.get('id'));
    localStorage.setItem('ssafyemp', JSON.stringify(empls));

    alert('삭제가 완료되었습니다.');
    location.href = './list.html';
  },
};
