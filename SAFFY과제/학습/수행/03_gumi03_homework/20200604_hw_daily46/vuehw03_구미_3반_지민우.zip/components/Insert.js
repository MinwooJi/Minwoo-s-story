export default {
  template: `
    <div>
        <table class="table">
        <tr>
            <th>이름</th>
            <td><input type="text" id="name" v-model="name" /></td>
        </tr>
        <tr>
            <th>이메일</th>
            <td><input type="text" id="email" v-model="email" /></td>
        </tr>
        <tr>
            <th>고용일</th>
            <td><input type="date" id="hiredate" v-model="hiredate" /></td>
        </tr>
        <tr>
            <th>관리자</th>
            <td><input type="text" id="supemp" v-model="supemp" /></td>
        </tr>
        <tr>
            <th>직책</th>
            <td>
            <select id="pos" v-model="pos">
                <option value="사장">사장</option>
                <option value="기획부장">기획부장</option>
                <option value="영업부장">영업부장</option>
                <option value="총무부장">총무부장</option>
                <option value="인사부장">인사부장</option>
                <option value="과장">과장</option>
                <option value="영업대표이사">영업대표이사</option>
                <option value="사원" selected>사원</option>
            </select>
            </td>
        </tr>
        <tr>
            <th>부서</th>
            <td><input type="select" id="dept" v-model="dept" /></td>
        </tr>
        <tr>
            <th>월급</th>
            <td><input type="text" id="sal" v-model="sal" /></td>
        </tr>
        <tr>
            <th>커미션</th>
            <td><input type="text" id="comm" v-model="comm" /></td>
        </tr>
        </table>
        <div class="text-right">
        <button class="btn btn-primary" @click="checkHandler">등록</button>
        <button class="btn btn-primary" @click="moveList">목록</button>
        </div>
    </div>
    `,
  data() {
    // data는 가져올떄 함수형(return으로 가져와야한다.)
    // 목록 데이터 저장을 위한 배열 선언(배열의 이름 : items)
    return {
      id: '',
      name: '',
      email: '',
      hiredate: '',
      supemp: '',
      pos: '',
      dept: '',
      sal: '',
      comm: '',
    };
  },
  methods: {
    checkHandler() {
      let err = true;
      let msg = '';
      !this.name && ((msg = '이름을 입력해주세요'), (err = false));
      err && !this.email && ((msg = '이메일을 입력해주세요'), (err = false));
      err && !this.hiredate && ((msg = '고용일을 입력해주세요'), (err = false));
      err && !this.supemp && ((msg = '관리자를 입력해주세요'), (err = false));
      err && !this.pos && ((msg = '직책을 입력해주세요'), (err = false));
      err && !this.dept && ((msg = '부서를 입력해주세요'), (err = false));
      err && !this.sal && ((msg = '월급을 입력해주세요'), (err = false));
      err && !this.comm && ((msg = '커미션을 입력해주세요'), (err = false));
      if (!err) alert(msg);
      else {
        this.createHandler();
      }
    },
    moveList() {
      location.href = './list.html';
    },
    createHandler() {
      const emp = localStorage.getItem('ssafyemp');
      let newEmp = {
        id: 0,
        empls: [],
      };
      console.dir(emp);
      if (emp) {
        newEmp = JSON.parse(emp);
      }
      newEmp.id++;
      newEmp.empls.push({
        id: newEmp.id,
        name: this.name,
        email: this.email,
        hiredate: this.hiredate,
        supemp: this.supemp,
        pos: this.pos,
        dept: this.dept,
        sal: this.sal,
        comm: this.comm,
      });
      localStorage.setItem('ssafyemp', JSON.stringify(newEmp));
      alert('사원등록 완료');
      this.moveList();
    },
  },
};
