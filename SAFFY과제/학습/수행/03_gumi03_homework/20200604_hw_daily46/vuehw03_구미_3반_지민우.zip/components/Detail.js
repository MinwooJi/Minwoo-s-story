export default {
  template: `
    <div>
    <table class="table table-bordered w-50">
        <tr>
            <th>id</th>
            <td>{{emp.id}}</td>
        </tr>
        <tr>
            <th>name</th>
            <td>{{emp.name}}</td>
        </tr>
        <tr>
            <th>email</th>
            <td>{{emp.email}}</td>
        </tr>
        <tr>
            <th>hiredate</th>
            <td>{{emp.hiredate}}</td>
        </tr>
        <tr>
            <th>supemp</th>
            <td>{{emp.supemp}}</td>
        </tr>
        <tr>
            <th>pos</th>
            <td>{{emp.pos}}</td>
        </tr>
        <tr>
            <th>dept</th>
            <td>{{emp.dept}}</td>
        </tr>
        <tr>
            <th>sal</th>
            <td>{{emp.sal}}</td>
        </tr>
        <tr>
            <th>comm</th>
            <td>{{emp.comm}}</td>
        </tr>
        </table>
        <br />
        <div class="text-center">
            <a href="./list.html" class="btn btn-primary">목록</a>
            <a :href="'./delete.html?id='+emp.id" class="btn btn-primary">삭제</a>
        </div>
    </div>
    `,
  data() {
    return {
      emp: {},
    };
  },
  created() {
    const params = new URL(document.location).searchParams;
    const emps = JSON.parse(localStorage.getItem('ssafyemp'));
    let empls = emps.empls;
    for (let emp of emps.empls) {
      if (emp.id == params.get('id')) {
        this.emp = emp;
        break;
      }
    }
  },
};
