export default {
  template: `
  <div>
    <div>
        <input type="text" id="name" v-model="name" />
        <button class="btn btn-primary" @click="findEmp">검색</button>
    </div>
    <div v-if="empls.length">
        <table class="table table-bordered table-condensed">
        <colgroup>
            <col :style="{width: '10%'}" />
            <col :style="{width: '50%'}" />
            <col :style="{width: '15%'}" />
            <col :style="{width: '25%'}" />
        </colgroup>
        <tr>
            <th>사원 아이디</th>
            <th>사원명</th>
            <th>부서</th>
            <th>직책</th>
            <th>연봉</th>
        </tr>
        <tr v-for="emp in empls">
            <td><a :href="'./detail.html?id='+emp.id">{{emp.id}}</a></td>
            <td>{{emp.name}}</td>
            <td>{{emp.dept}}</td>
            <td>{{emp.pos}}</td>
            <td>{{emp.sal*12}}</td>
        </tr>
        </table>
    </div>
    <div v-else class="text-center">
        등록 된 사원이 없습니다.
    </div>
    <div class="text-right">
        <button class="btn btn-primary" @click="moveToInsert">사원등록</button>
    </div>
</div>
    `,
  data() {
    return {
      name: '',
      empls: [],
    };
  },

  created: function () {
    const emp = localStorage.getItem('ssafyemp');
    let newEmp = {
      // 빈객체
      id: 0,
      empls: [],
    };
    if (emp) {
      // 입력값이 있을때
      newEmp = JSON.parse(emp);
    } else {
      localStorage.setItem('ssafyemp', JSON.stringify(newEmp));
    }
    newEmp.empls.sort((a, b) => {
      // comporator
      return -(a.id - b.id);
    });
    this.empls = newEmp.empls; // 대입
  },
  methods: {
    moveToInsert() {
      location.href = './insert.html';
    },
    findEmp() {
      const emps = JSON.parse(localStorage.getItem('ssafyemp'));

      if (this.name) {
        if (emps.length == 0) {
          alert('회원정보가 없습니다.');
        } else {
          this.empls = [];
          for (let emp of emps.empls) {
            if (emp.name.includes(this.name)) this.empls.push(emp);
          }
        }
      } else {
        alert('검색할 이름을 입력하세요');
      }
    },
  },
};
