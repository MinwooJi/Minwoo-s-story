use ssafyweb;
CREATE TABLE product (
 productno        INT NOT NULL AUTO_INCREMENT,
 productname     VARCHAR(20),
 price    INT,
 info   VARCHAR(100),
  PRIMARY KEY(productno)
);