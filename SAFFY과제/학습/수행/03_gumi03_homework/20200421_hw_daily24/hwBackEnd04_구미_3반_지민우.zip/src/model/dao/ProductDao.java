package model.dao;

import java.sql.SQLException;
import java.util.List;

import model.dto.ProductDto;

public interface ProductDao {
	public ProductDto getProduct(String userid) throws SQLException;
	public List<ProductDto> selectByPrice(int price) throws SQLException;
	public List<ProductDto> selectAll() throws SQLException;
	public void insert(ProductDto productDto) throws SQLException;
	public void delete(String productno) throws SQLException;
}
