package model.service;

import java.sql.SQLException;
import java.util.List;

import model.dao.ProductDao;
import model.dao.ProductDaoImpl;
import model.dto.ProductDto;

public class ProductServiceImpl implements ProductService {
	ProductDao productDao;
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	@Override
	public List<ProductDto> selectByPrice(int price) {
		List<ProductDto>list = null;
		try {
			list =  productDao.selectByPrice(price);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public void insert(ProductDto productDto) {
		try {
			productDao.insert(productDto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void delete(String productno) {
		try {
			productDao.delete(productno);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
