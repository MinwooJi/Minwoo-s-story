package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.dto.ProductDto;
import util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public ProductDto getProduct(String userid) throws SQLException {
		ProductDto productDto = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, info ");
			sql.append("  from product                 ");
			sql.append("  where productno in           ");
			sql.append("    (select max(productno)     ");
			sql.append("       from myproduct          ");
			sql.append("       where userid = ?) ");
			pstmt = conn.prepareStatement(sql.toString());
			int idx = 1;
			pstmt.setString(idx++, userid);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				productDto = new ProductDto();
				productDto.setInfo(rs.getString("info"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setProductno(rs.getInt("productno"));
				productDto.setProductname(rs.getString("productname"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
	}

	@Override
	public List<ProductDto> selectByPrice(int price) throws SQLException {
		ProductDto productDto = null;
		List<ProductDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, info ");
			sql.append("  from product                 ");
			sql.append("  where price <= ?           ");
			pstmt = conn.prepareStatement(sql.toString());
			int idx = 1;
			pstmt.setInt(idx++, price);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				productDto = new ProductDto();
				productDto.setInfo(rs.getString("info"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setProductno(rs.getInt("productno"));
				productDto.setProductname(rs.getString("productname"));
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return list;
	}

	@Override
	public List<ProductDto> selectAll() throws SQLException {
		ProductDto productDto = null;
		List<ProductDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, info ");
			sql.append("  from product                 ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				productDto = new ProductDto();
				productDto.setInfo(rs.getString("info"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setProductno(rs.getInt("productno"));
				productDto.setProductname(rs.getString("productname"));
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return list;
	}

	@Override
	public void insert(ProductDto productDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product(productname,price,info ) ");
			sql.append("values (?,?,?) ");
			pstmt = conn.prepareStatement(sql.toString());
			int index = 1;
			pstmt.setString(index++, productDto.getProductname());
			pstmt.setInt(index++, productDto.getPrice());
			pstmt.setString(index++, productDto.getInfo());
			
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public void delete(String productno) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("delete from product ");
			sql.append("where productno = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			int index = 1;
			pstmt.setString(index++, productno);
			
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
	}

}
