package model.dto;

public class ProductDto {
	 // productno 
    private Integer productno;

    // productName 
    private String productname;

    // price 
    private Integer price;

    // info 
    private String info;

    public Integer getProductno() {
        return productno;
    }

    public void setProductno(Integer productno) {
        this.productno = productno;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    // Product 모델 복사
    public void CopyData(ProductDto param)
    {
        this.productno = param.getProductno();
        this.productname = param.getProductname();
        this.price = param.getPrice();
        this.info = param.getInfo();
    }
}
