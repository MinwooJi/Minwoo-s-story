package model.service;

import java.util.List;

import model.dto.ProductDto;

public interface ProductService {
	public List<ProductDto> selectByPrice(int price);
	public void insert(ProductDto productDto);
	public void delete(String productno);
}
