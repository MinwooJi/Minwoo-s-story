package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dto.ProductDto;
import model.service.ProductService;
import model.service.ProductServiceImpl;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ProductService productService;
	
	public void init() {
		productService = new ProductServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request,response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("act");
		String path = "";
		switch (act == null ? "" : act) {
		case "list":
			path = list(request,response);
			break;
		case "insertForm":
			path = insertForm(request,response);
			break;
		case "delete":
			path = delete(request,response);
			break;
		case "insert":
			path = insert(request,response);
			break;
		default:
			path = "/main.jsp";
			break;
		}
		if(path.startsWith("redirect:")) {
			response.sendRedirect(request.getContextPath()+path.substring("redirect:".length()));
			return;
		}
		RequestDispatcher rd = request.getRequestDispatcher(path);
		rd.forward(request, response);
	}

	private String delete(HttpServletRequest request, HttpServletResponse response) {
		String productno = request.getParameter("productno");
		productService.delete(productno);
		return "deleteResult.jsp";
	}

	private String insert(HttpServletRequest request, HttpServletResponse response) {
		String productname = request.getParameter("productname");
		int price = Integer.parseInt(request.getParameter("price"));
		String info = request.getParameter("info");
		ProductDto productDto = new ProductDto();
		productDto.setInfo(info);
		productDto.setPrice(price);
		productDto.setProductname(productname);
		productService.insert(productDto);
		return "insertSuccess.jsp";
	}


	private String insertForm(HttpServletRequest request, HttpServletResponse response) {
		return "/insertForm.jsp";
	}

	private String list(HttpServletRequest request, HttpServletResponse response) {
		String temp = request.getParameter("price");
		int price;
		if("".equals(temp)) {
			price = Integer.MAX_VALUE;
		}else {
			price = Integer.parseInt(temp);
		}
		String searchType = "price";
		List<ProductDto>list = productService.selectByPrice(price);
		request.setAttribute("list", list);
		return "/main.jsp";
	}
	
}
