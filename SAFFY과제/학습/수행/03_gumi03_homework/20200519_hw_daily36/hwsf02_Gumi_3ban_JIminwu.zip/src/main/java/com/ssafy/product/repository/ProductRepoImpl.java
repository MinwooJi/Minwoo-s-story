package com.ssafy.product.repository;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;
import com.ssafy.util.DBUtil;
@Repository("productRepo")
public class ProductRepoImpl implements ProductRepo{
	@Override
	public List<Product> selectAll() throws SQLException {
		List<Product>list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * ");
			sql.append("from product ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				list.add(product);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return list;
	}

	@Override
	public Product select(String id) throws SQLException {
		Product product = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * ");
			sql.append("from product ");
			sql.append("where id = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return product;
	}

	@Override
	public int insert(Product product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		int rst = 0;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(100);
			sql.append("insert into product(id, name, price, description) ");
			sql.append("values (?, ?, ?, ?)");
			stmt = con.prepareStatement(sql.toString());
			int idx = 1;
			stmt.setString(idx++, product.getId());
			stmt.setString(idx++, product.getName());
			stmt.setInt(idx++, product.getPrice());
			stmt.setString(idx++, product.getDescription());
			rst = stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return rst;
	}

	@Override
	public int update(Product product) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		int rst = 0;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(100);
			sql.append("update product set name=?,price=?,description=? ");
			sql.append("where id = ? ");
			stmt = con.prepareStatement(sql.toString());
			int idx = 1;
			stmt.setString(idx++, product.getName());
			stmt.setInt(idx++, product.getPrice());
			stmt.setString(idx++, product.getDescription());
			stmt.setString(idx++, product.getId());
			rst = stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return rst;
	}

	@Override
	public int delete(String id) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		int rst = 0;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder(100);
			sql.append("delete from product ");
			sql.append("where id = ? ");
			stmt = con.prepareStatement(sql.toString());
			stmt.setString(1, id);
			
			rst = stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return rst;
	}

}
