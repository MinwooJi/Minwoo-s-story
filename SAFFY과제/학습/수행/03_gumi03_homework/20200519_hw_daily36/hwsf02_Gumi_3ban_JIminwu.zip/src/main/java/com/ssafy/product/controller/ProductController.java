package com.ssafy.product.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	@GetMapping("/listProduct.do")
	public String productkList(Model model) {
		try {
			model.addAttribute("list", productService.selectAll());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "product/listProduct";
	}	
	
	@GetMapping("/insertProductForm.do")
	public String insertProductForm() {
		return "product/insertProduct";
	}
	
	@PostMapping("/insertProduct.do")
	public String insertProduct(Product product) {
		try {
			productService.insert(product);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "redirect:listProduct.do";
	}
//	@GetMapping("/updateProductForm.do")
//	public String insertProductForm(String id, Model model) {
//		try {
//			model.addAttribute("product", productService.select(id));
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return "product/updateProduct";
//	}
//	
//	@PostMapping("/updateProduct.do")
//	public String updateProduct(Product product) {
//		try {
//			productService.update(product);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return "redirect:listProduct.do";
//	}
//	
//	@GetMapping("/removeProduct.do")
//	public String removeProduct(String id) {
//		try {
//			productService.delete(id);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return "redirect:listProduct.do";
//	}

}
