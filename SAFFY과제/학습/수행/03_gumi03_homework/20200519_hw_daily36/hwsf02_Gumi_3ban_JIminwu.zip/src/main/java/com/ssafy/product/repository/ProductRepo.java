package com.ssafy.product.repository;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductRepo {
	List<Product>selectAll() throws SQLException;
	Product select(String id) throws SQLException;
	int insert(Product product) throws SQLException;
	int update(Product product) throws SQLException;
	int delete(String id) throws SQLException;
}
