package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repository.ProductRepo;

@Service("productService")
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepo productRepo;
	@Override
	public ProductRepo getRepo() {
		// TODO Auto-generated method stub
		return this.productRepo;
	}

	@Override
	public List<Product> selectAll() throws SQLException{
		// TODO Auto-generated method stub
		return productRepo.selectAll();
	}

	@Override
	public Product select(String id) throws SQLException {
		// TODO Auto-generated method stub
		return productRepo.select(id);
	}

	@Override
	public int insert(Product product) throws SQLException {
		// TODO Auto-generated method stub
		return productRepo.insert(product);
	}

	@Override
	public int update(Product product) throws SQLException {
		// TODO Auto-generated method stub
		return productRepo.update(product);
	}

	@Override
	public int delete(String id) throws SQLException {
		// TODO Auto-generated method stub
		return productRepo.delete(id);
	}

}
