package com.ssafy.hrm.dao;

import java.util.List;

import com.ssafy.hrm.dto.Employee;

public interface EmployeeDAO {
	public List<Employee> selectEmployee();
	public Employee selectEmployeeById(int id);
	public int insertEmployee(Employee emp);
	public int updateEmployee(Employee emp);
	public int deleteEmployee(int id);
	public int selectEmployeeMaxId();
}
