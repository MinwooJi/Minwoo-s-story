package com.ssafy.hrm.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.hrm.dto.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	private final static String NS = "com.ssafy.hrm.dao.EmployeeDAO.";
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Employee> selectEmployee() {
		return sqlSession.selectList(NS + "selectEmployee");
	}
	

	@Override
	public int insertEmployee(Employee emp){
		return sqlSession.insert(NS + "insertEmployee",emp);
	}


	@Override
	public Employee selectEmployeeById(int id){
		return sqlSession.selectOne(NS + "selectEmployeeById",id);
	}

	@Override
	public int updateEmployee(Employee emp){
		 return sqlSession.update(NS + "updateEmployee",emp);
	}

	@Override
	public int deleteEmployee(int id) {
		return sqlSession.delete(NS + "deleteEmployee",id);
	}


	@Override
	public int selectEmployeeMaxId() {
		return sqlSession.selectOne(NS + "selectEmployeeMaxId");
	}

	
}
