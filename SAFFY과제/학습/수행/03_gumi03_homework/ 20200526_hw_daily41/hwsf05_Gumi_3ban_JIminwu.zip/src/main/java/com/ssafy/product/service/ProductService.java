package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repository.ProductRepo;

public interface ProductService {
	ProductRepo getRepo();
	List<Product> selectAll();	
	Product select(String id);
	void insert(Product product);
	void update(Product product);
	void delete(String id);
}
