package com.ssafy.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	@Autowired
	ProductService productService;
	@GetMapping("/listProduct")
	public ResponseEntity<List<Product>> listProduct() {
		return new ResponseEntity<>(productService.selectAll(),HttpStatus.OK);
	}	
	@GetMapping("/searchProduct")
	public ResponseEntity<Product> searchProduct(String id) {
		return new ResponseEntity<>(productService.select(id),HttpStatus.OK);
	}	
	
	@PostMapping("/insertProduct")
	public ResponseEntity<String> insertProduct(Product product) {
		productService.insert(product);
		return new ResponseEntity<>("SUCCESS",HttpStatus.OK);
	}
	@PostMapping("/updateProduct")
	public ResponseEntity<String> updateProduct(Product product) {
		productService.update(product);
		return new ResponseEntity<>("SUCCESS",HttpStatus.OK);
	}
	@GetMapping("/deleteProduct")
	public ResponseEntity<String> deleteProduct(String id) {
		productService.delete(id);
		return new ResponseEntity<>("SUCCESS",HttpStatus.OK);
	}
}
