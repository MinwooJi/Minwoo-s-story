package com.ssafy.product.repository;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductRepo {
	List<Product>selectProduct();
	Product selectProductById(String id);
	void insertProduct(Product product);
	void updateProduct(Product product);
	void deleteProduct(String id);
}
