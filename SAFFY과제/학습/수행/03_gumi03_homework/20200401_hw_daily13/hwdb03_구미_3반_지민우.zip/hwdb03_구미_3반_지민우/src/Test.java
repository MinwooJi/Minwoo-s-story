
public class Test {
	public static void main(String[] args) {
		ProductUI pUI = new ProductUI();
		pUI.service();
	}
}
