import java.sql.SQLException;
import java.util.List;

public interface DAO {
	public List<Product> selectProduct() throws SQLException;
	public Product selectOneProduct(String prdtcode) throws SQLException;
	public void insertProduct(Product p) throws SQLException;
	public void updateProduct(Product p) throws SQLException;
	public void deleteProduct(String prdtcode) throws SQLException;
}
