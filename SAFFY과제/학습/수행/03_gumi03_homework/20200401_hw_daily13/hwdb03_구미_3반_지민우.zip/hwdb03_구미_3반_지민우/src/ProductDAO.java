import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO implements DAO {
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("class loading failure");
		}
	}
	private Connection getConnection() throws SQLException {
		Connection con = DriverManager.getConnection
				("jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","ssafy");
		return con;
	}
	@Override
	public List<Product> selectProduct() throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Product> list = new ArrayList<>();
		try {
			con = getConnection();
			String query = "select prdtcode,name,price "
					     + "from product";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			Product p;
			while(rs.next()) {
				p = new Product(rs.getString("prdtcode"),rs.getString("name"),rs.getInt("price"));
				list.add(p);
			}
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public Product selectOneProduct(String prdtcode) throws SQLException {
		Product temp = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			String query = "select prdtcode,name,price "
				     + "from product "
				     + "where prdtcode = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, prdtcode);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				temp = new Product(rs.getString("prdtcode"),rs.getString("name"),rs.getInt("price"));
			}
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return temp;
	}

	@Override
	public void insertProduct(Product p) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = getConnection();
			String query = "insert into product(prdtcode,name,price) "
					+ "values(?,?,?) ";
			pstmt = con.prepareStatement(query);
			int idx = 1;
			pstmt.setString(idx++, p.getPrdtcode());
			pstmt.setString(idx++, p.getName());
			pstmt.setInt(idx++, p.getPrice());
			pstmt.executeUpdate();
			
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void updateProduct(Product p) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = getConnection();
			String query = "update product "
					+ "set name=?,price=? "
					+ "where prdtcode = ? ";
			pstmt = con.prepareStatement(query);
			int idx = 1;
			pstmt.setString(idx++,p.getName());
			pstmt.setInt(idx++,p.getPrice());
			pstmt.setString(idx++,p.getPrdtcode());
			pstmt.executeUpdate();
			
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void deleteProduct(String prdtcode) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = getConnection();
			String query = "delete "
					+ "from product "
					+ "where prdtcode = ? ";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, prdtcode);
			pstmt.executeUpdate();
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
