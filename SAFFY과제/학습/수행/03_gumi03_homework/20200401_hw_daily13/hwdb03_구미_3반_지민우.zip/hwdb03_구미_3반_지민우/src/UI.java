
public interface UI {
	public void serviceSelectAll();
	public void serviceSelectOne(String code);
	public void serviceInsert(Product p);
	public void serviceDelete(String code);
	public void serviceUpdate(Product p);
	public void menu();
	public void service();
}
