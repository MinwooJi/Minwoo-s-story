import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ProductUI implements UI{
	private ProductDAO dao;

	public ProductUI() {
		dao = new ProductDAO();
	}

	@Override
	public void serviceSelectAll() {
		try {
			List<Product> list = dao.selectProduct();
			System.out.println("--------------------------------");
			System.out.println(String.format("%-10s  %-20s  %-10s", "제품코드","이름","가격"));
			System.out.println("--------------------------------");
			for (Product product : list) {
				System.out.println(
						String.format("%-10s", product.getPrdtcode()) +
						String.format("%-15s", product.getName()) +
						String.format("%-10d", product.getPrice())
						);
			}
			System.out.println("--------------------------------");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void serviceSelectOne(String code) {
		Product temp;
		try {
			temp = dao.selectOneProduct(code);
			if(temp != null) {
				System.out.println("찾았습니다.");
				System.out.println(temp);
			}else {
				System.out.println("상품번호를 확인하세요");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void serviceInsert(Product p) {
		try {
			dao.insertProduct(p);
			System.out.println("입력완료");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void serviceDelete(String code) {
		try {
			dao.deleteProduct(code);
			System.out.println("삭제완료");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void serviceUpdate(Product p) {
		try {
			dao.updateProduct(p);
			System.out.println("수정완료");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void menu() {
		System.out.println("1. 전체상품 조회");
		System.out.println("2. 상세상품 조회");
		System.out.println("3. 새로운 상품 저장");
		System.out.println("4. 상품정보 수정");
		System.out.println("5. 상품정보 삭제");
		System.out.println("0. 서비스 종료");
		System.out.println();
		System.out.println("이용할 서비스 번호를 입력하십시오.: ");
	}

	@Override
	public void service() {
			while(true) {
				menu();
				Scanner sc = new Scanner(System.in);
				int func = sc.nextInt();
				switch(func) {
				case 0 :
					return;
				case 1 :
					serviceSelectAll();
					break;
				case 2 :
					System.out.println("검색할 상품의 코드를 입력하세요: ");
					serviceSelectOne(sc.next());
					break;
				case 3 :
					System.out.println("새로 입력할 상품의 상품코드 / 이름 / 가격을 순서대로 입력하세요: ");
					serviceInsert(new Product(sc.next(), sc.next(), sc.nextInt()));
					break;
				case 4 :
					System.out.println("수정할 상품의 상품코드 / 수정할 이름 / 수정할 가격을 순서대로 입력하세요: ");
					serviceUpdate(new Product(sc.next(), sc.next(), sc.nextInt()));
					break;
				case 5 :
					System.out.println("삭제할 상품의 상품코드를 입력하세요");
					serviceDelete(sc.next());
					break;
				default :
					System.out.println("서비스 번호를 확인하세요");
					break;
				}
				
				
			}
		
	}

}
