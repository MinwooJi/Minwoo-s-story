package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repository.ProductRepo;

@Service("productService")
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepo productRepo;
	@Override
	public ProductRepo getRepo() {
		// TODO Auto-generated method stub
		return this.productRepo;
	}

	@Override
	public List<Product> selectAll(){
		// TODO Auto-generated method stub
		return productRepo.selectProduct();
	}

	@Override
	public Product select(String id) {
		// TODO Auto-generated method stub
		return productRepo.selectProductById(id);
	}

	@Override
	public void insert(Product product) {
		// TODO Auto-generated method stub
		productRepo.insertProduct(product);
	}

	@Override
	public void update(Product product) {
		// TODO Auto-generated method stub
		productRepo.updateProduct(product);
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		productRepo.deleteProduct(id);
	}

}
