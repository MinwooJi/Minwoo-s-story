use ssafydb;
CREATE TABLE product
(
    `id`           VARCHAR(45)    NOT NULL, 
    `name`         VARCHAR(45)    NULL, 
    `price`        int            NULL, 
    `description`  VARCHAR(45)    NULL, 
    PRIMARY KEY (id)
);
insert into product(id, name, price, description)
values ('ssafy', 'ssafy', 10000, '싸피프로덕트');
select * from product;