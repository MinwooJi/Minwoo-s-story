package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

public interface ProductService {
	ProductRepo getRepo() throws SQLException;
	List<Product> selectAll() throws SQLException;	
	Product select(String id) throws SQLException;
	int insert(Product product) throws SQLException;
	int update(Product product) throws SQLException;
	int delete(String id) throws SQLException;
}
