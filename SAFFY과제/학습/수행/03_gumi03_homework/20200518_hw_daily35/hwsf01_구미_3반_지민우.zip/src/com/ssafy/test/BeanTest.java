package com.ssafy.test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

public class BeanTest {
	ProductService productService;
	public BeanTest() {
		GenericApplicationContext container = new GenericXmlApplicationContext("applicationContext.xml");
		productService = (ProductService)container.getBean("productService");
		System.out.println("productService 생성자 호출");
		container.close();
	}
	public static void main(String[] args) {
		BeanTest beanTest = new BeanTest();
		List<Product>list = new ArrayList<>();
		Product prod;
		try {
			System.out.println("전체조회");
			System.out.println("----------------------------------------");
			list = beanTest.productService.selectAll();
			for (Product product : list) {
				System.out.println(product);
			}
			System.out.println("\n 테스트 상품 삽입");
			System.out.println("----------------------------------------");
			beanTest.productService.insert(new Product("테스트아이디","테스트이름",99999,"테스트설명입니다"));
			beanTest.productService.selectAll();
			list = beanTest.productService.selectAll();
			for (Product product : list) {
				System.out.println(product);
			}
			System.out.println("\n ssafy 검색");
			System.out.println("----------------------------------------");
			prod = beanTest.productService.select("ssafy");
			System.out.println(prod);
			
			System.out.println("\n update 테스트");
			System.out.println("----------------------------------------");
			beanTest.productService.update(new Product("테스트아이디","테스트이름수정",111111,"테스트설명수정입니다"));
			list = beanTest.productService.selectAll();
			for (Product product : list) {
				System.out.println(product);
			}
			System.out.println("\n 테스트 삭제");
			System.out.println("----------------------------------------");
			beanTest.productService.delete("테스트아이디");
			list = beanTest.productService.selectAll();
			for (Product product : list) {
				System.out.println(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
