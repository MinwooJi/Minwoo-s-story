create database ssafyweb;
use ssafyweb;
-- drop table ssafy_member;
-- drop table product;
-- drop table myproduct;
CREATE TABLE `ssafy_member` (
	`userid`	VARCHAR(20) 	PRIMARY KEY,
	`username`	VARCHAR(20) 	NOT NULL,
	`userpwd`	VARCHAR(100) 	NOT NULL,
	`email`		VARCHAR(2000),
	`address` 	VARCHAR(2000),
	`joindate` 	TIMESTAMP		NOT NULL DEFAULT current_timestamp
);

INSERT INTO ssafy_member (userid, username, userpwd, email, address)
VALUES('admin', '관리자', 'admin', 'admin@ssafy.com','서울시 역삼동');

INSERT INTO ssafy_member (userid, username, userpwd, email, address)
VALUES('ssafy', '김싸피', 'ssafy', 'ssafy@ssafy.com','대전시 덕명동');

CREATE TABLE Product
(
    `productno`    INT             NOT NULL    AUTO_INCREMENT COMMENT 'productno', 
    `productname`  VARCHAR(45)     NULL        COMMENT 'productname', 
    `price`    INT             NULL        COMMENT 'price', 
    `info`     VARCHAR(100)    NULL        COMMENT 'info', 
    PRIMARY KEY (productno)
);

ALTER TABLE Product COMMENT 'Product';
CREATE TABLE myproduct
(
    `productno`    INT            NOT NULL    COMMENT 'productno', 
    `userid`       VARCHAR(45)    NULL        COMMENT 'userid', 
    `myproductno`  INT            NOT NULL    AUTO_INCREMENT COMMENT 'myproductno', 
    PRIMARY KEY (myproductno)
);

ALTER TABLE myproduct
    ADD CONSTRAINT FK_myproduct_productno_Product_productno FOREIGN KEY (productno)
        REFERENCES Product (productno) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE myproduct
    ADD CONSTRAINT FK_myproduct_userid_ssafy_member_userid FOREIGN KEY (userid)
        REFERENCES ssafy_member (userid) ON DELETE RESTRICT ON UPDATE RESTRICT;
        
INSERT INTO Product (productname, price, info)
VALUES('smart TV', '50000', 'Smart....');
INSERT INTO Product (productname, price, info)
VALUES('ssafy Computer', '500000', 'SSafy....');
INSERT INTO Product (productname, price, info)
VALUES('Samsung CROWN', '50000000', 'LOL....');


INSERT INTO myproduct (productno, userid)
VALUES(1, 'ssafy');
INSERT INTO myproduct (productno, userid)
VALUES(2, 'ssafy');
INSERT INTO myproduct (productno, userid)
VALUES(3, 'admin');

commit;