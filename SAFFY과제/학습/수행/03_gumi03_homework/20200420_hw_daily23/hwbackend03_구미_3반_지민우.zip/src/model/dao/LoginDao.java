package model.dao;

import java.sql.SQLException;

import model.dto.MemberDto;

public interface LoginDao {

	public MemberDto login(String userid, String userpwd) throws SQLException;
	
}
