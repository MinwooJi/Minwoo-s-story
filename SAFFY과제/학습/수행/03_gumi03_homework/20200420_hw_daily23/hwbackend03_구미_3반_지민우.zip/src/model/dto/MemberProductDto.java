package model.dto;

public class MemberProductDto {
	private int prdNo;
}
