package model.dao;

import java.sql.SQLException;

import model.dto.ProductDto;

public interface ProductDao {
	public ProductDto getProduct(String userid) throws SQLException;
}
