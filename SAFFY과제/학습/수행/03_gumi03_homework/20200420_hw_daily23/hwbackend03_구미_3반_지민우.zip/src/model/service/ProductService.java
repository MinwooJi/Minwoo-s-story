package model.service;

import model.dto.MemberDto;
import model.dto.ProductDto;

public interface ProductService {
	public ProductDto selectLast(MemberDto memberDto) throws Exception;
}
