package model.service;

import model.dao.ProductDao;
import model.dao.ProductDaoImpl;
import model.dto.MemberDto;
import model.dto.ProductDto;

public class ProductServiceImpl implements ProductService {
	ProductDao productDao;
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	@Override
	public ProductDto selectLast(MemberDto memberDto) throws Exception {
		ProductDto productDto = productDao.getProduct(memberDto.getUserid());
		return productDto;
	}

}
