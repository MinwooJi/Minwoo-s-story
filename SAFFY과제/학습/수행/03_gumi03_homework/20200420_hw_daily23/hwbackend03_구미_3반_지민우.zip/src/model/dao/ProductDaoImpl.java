package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.dto.ProductDto;
import util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public ProductDto getProduct(String userid) throws SQLException {
		ProductDto productDto = null;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, info ");
			sql.append("  from product                 ");
			sql.append("  where productno in           ");
			sql.append("    (select max(productno)     ");
			sql.append("       from myproduct          ");
			sql.append("       where userid = ?) ");
			pstmt = conn.prepareStatement(sql.toString());
			int idx = 1;
			pstmt.setString(idx++, userid);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				productDto = new ProductDto();
				productDto.setInfo(rs.getString("info"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setProductno(rs.getInt("productno"));
				productDto.setProductname(rs.getString("productname"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
	}

}
