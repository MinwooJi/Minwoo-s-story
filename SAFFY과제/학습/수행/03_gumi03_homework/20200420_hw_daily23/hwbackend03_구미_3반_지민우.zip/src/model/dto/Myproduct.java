package model.dto;

public class Myproduct {

    // productno 
    private Integer productno;

    // userid 
    private String userid;

    // myproductno 
    private Integer myproductno;

    public Integer getProductno() {
        return productno;
    }

    public void setProductno(Integer productno) {
        this.productno = productno;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public Integer getMyproductno() {
        return myproductno;
    }

    public void setMyproductno(Integer myproductno) {
        this.myproductno = myproductno;
    }

    // Myproduct 모델 복사
    public void CopyData(Myproduct param)
    {
        this.productno = param.getProductno();
        this.userid = param.getUserid();
        this.myproductno = param.getMyproductno();
    }
}
