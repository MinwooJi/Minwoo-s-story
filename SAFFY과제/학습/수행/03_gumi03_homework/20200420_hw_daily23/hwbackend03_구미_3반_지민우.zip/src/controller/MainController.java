package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.dto.MemberDto;
import model.dto.ProductDto;
import model.service.LoginService;
import model.service.LoginServiceImpl;
import model.service.ProductService;
import model.service.ProductServiceImpl;

@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private LoginService loginService;
	private ProductService productService;
	
	public void init() {
		loginService = new LoginServiceImpl();
		productService = new ProductServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request,response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("act");
		if("login".equals(act)) {
			login(request, response);
		}else if("logout".equals(act)) {
			logout(request, response);
		}
	}
	private void selectLast(MemberDto memberDto,HttpServletRequest request, HttpServletResponse response,String path) throws ServletException, IOException{
		ProductDto productDto = null;
		try {
			productDto = productService.selectLast(memberDto);
			if(productDto != null) {
				request.setAttribute("product", productDto);
			}else {
				request.setAttribute("msg", "등록되있는 상품을 확인 해 주세요.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response);
		
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		MemberDto memberDto = null;
		try {
			memberDto = loginService.login(userid, userpwd);
			if(memberDto != null) { // 로그인 성공
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
			}else { // 실패
				request.setAttribute("msg", "아이디 또는 비밀번호를 확인 해 주세요.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		selectLast(memberDto,request,response,path);
	}
	private void logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		session.invalidate();
		request.getRequestDispatcher(path).forward(request, response);
	}
	
}
