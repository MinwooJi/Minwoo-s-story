/**
 * MyMap 생성자로 사용될 함수를 구현
 */
function MyMap(){
	this.map = new Array();
}
MyMap.prototype.put = function(key,value){
	this.map[key] = value;
}
MyMap.prototype.size = function(){
	var cnt = 0;
	for(var idx in this.map){
		cnt++;
	}
	return cnt;
}
MyMap.prototype.get = function(key){
	return this.map[key];
}
MyMap.prototype.remove = function(key){
	delete this.map[key]
}
MyMap.prototype.clear = function(){
	for(var idx in this.map){
		delete this.map[idx];
	}
}