import Vue from 'vue';
import VueRouter from 'vue-router';
import Delete from '@/components/Delete.vue';
import Detail from '@/components/Detail.vue';
import Index from '@/components/Index.vue';
import Insert from '@//components/Insert.vue';
import List from '@//components/List.vue';
import Update from '@/components/Update.vue';

Vue.use(VueRouter);

export default new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/',
      component: Index,
    },
    {
      path: '/delete',
      component: Delete,
    },
    {
      path: '/detail',
      component: Detail,
    },
    {
      path: '/insert',
      component: Insert,
    },
    {
      path: '/list',
      component: List,
    },
    {
      path: '/update',
      component: Update,
    },
  ],
});
