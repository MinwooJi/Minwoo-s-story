import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    empls: [],
    emp: {},
  },
  actions: {
    getEmps(context) {
      axios
        .get('http://localhost:8097/hrmboot/api/employee/all')
        .then(({ data }) => {
          console.dir(data);
          context.commit('setEmps', data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
    getEmp(context, payload) {
      axios
        .get(payload)
        .then(({ data }) => {
          console.dir(data);
          context.commit('setEmp', data);
        })
        .catch((error) => {
          console.dir(error);
        });
    },
  },
  mutations: {
    setEmps(state, payload) {
      state.empls = payload;
    },
    setEmp(state, payload) {
      state.emp = payload;
    },
  },
  getters: {
    // 복잡한 계산식을 처리 : computed
    empls(state) {
      return state.empls;
    },
    emp(state) {
      return state.emp;
    },
  },
});
