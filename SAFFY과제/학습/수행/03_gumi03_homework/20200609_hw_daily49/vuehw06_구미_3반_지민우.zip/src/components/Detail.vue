<template>
  <div>
    <table class="table table-bordered w-50">
      <tr>
        <th>id</th>
        <td>{{ emp.id }}</td>
      </tr>
      <tr>
        <th>name</th>
        <td>{{ emp.cname }}</td>
      </tr>
      <tr>
        <th>email</th>
        <td>{{ emp.mailid }}</td>
      </tr>
      <tr>
        <th>hiredate</th>
        <td>{{ emp.start_date }}</td>
      </tr>
      <tr>
        <th>manager_id</th>
        <td>{{ emp.manager_id }}</td>
      </tr>
      <tr>
        <th>title</th>
        <td>{{ emp.title }}</td>
      </tr>
      <tr>
        <th>dept_id</th>
        <td>{{ emp.dept_id }}</td>
      </tr>
      <tr>
        <th>salary</th>
        <td>{{ emp.salary }}만원</td>
      </tr>
      <tr>
        <th>commission_pct</th>
        <td>{{ emp.commission_pct }}</td>
      </tr>
    </table>

    <br />
    <div class="text-center">
      <router-link to="/list" class="btn btn-primary">목록</router-link>
      <router-link :to="'/update?id=' + emp.id" class="btn btn-primary">수정</router-link>
      <router-link :to="'/delete?id=' + emp.id" class="btn btn-primary">삭제</router-link>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "Detail",
  computed: {
    ...mapGetters(["emp"])
  },
  created() {
    // const id = new URL(document.location).searchParams.get("id");
    // console.log(id)
    console.log("확인");
    console.dir(this.$route.query.id);
    this.$store.dispatch(
      "getEmp",
      `http://localhost:8097/hrmboot/api/employee/${this.$route.query.id}`
    );
  }
};
</script>

<style></style>
