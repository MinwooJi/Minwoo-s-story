<template>
  <div>
    삭제중...
  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'delete',
  created() {
    const params = new URL(document.location).searchParams;
    axios
      .delete(`http://localhost:8097/hrmboot/api/employee/${params.get('id')}`)
      .then(({ data }) => {
        if (data === 'success') {
          alert('삭제가 완료되었습니다.');
        } else {
          alert('삭제 처리시 문제가 발생했습니다.');
        }
      })
      .catch((error) => {
        console.dir(error);
      })
      .finally(() => {
        this.$router.push('/list');
      });
  },
};
</script>

<style></style>
