package com.ssafy.product.repository;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductRepo {
	List<Product>selectProduct() throws SQLException;
	Product selectProductById(String id) throws SQLException;
	void insertProduct(Product product) throws SQLException;
	void updateProduct(Product product) throws SQLException;
	void deleteProduct(String id) throws SQLException;
}
