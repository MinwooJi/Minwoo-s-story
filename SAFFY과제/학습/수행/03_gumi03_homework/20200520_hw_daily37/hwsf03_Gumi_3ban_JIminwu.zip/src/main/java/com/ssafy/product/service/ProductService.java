package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repository.ProductRepo;

public interface ProductService {
	ProductRepo getRepo() throws SQLException;
	List<Product> selectAll() throws SQLException;	
	Product select(String id) throws SQLException;
	void insert(Product product) throws SQLException;
	void update(Product product) throws SQLException;
	void delete(String id) throws SQLException;
}
