package com.ssafy.product.repository;


import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;
@Repository("productRepo")
public class ProductRepoImpl implements ProductRepo{
	private static final String NS = "com.ssafy.product.repository.ProductRepo.";
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Product> selectProduct() throws SQLException {
		return sqlSession.selectList(NS + "selectProduct");
	}

	@Override
	public Product selectProductById(String id) throws SQLException {
		return sqlSession.selectOne(NS + "selectProductById",id);
	}

	@Override
	public void insertProduct(Product product) throws SQLException {
		sqlSession.insert(NS + "insertProduct",product);
	}

	@Override
	public void updateProduct(Product product) throws SQLException {
		sqlSession.update(NS + "updateProduct",product);
	}

	@Override
	public void deleteProduct(String id) throws SQLException {
		sqlSession.delete(NS + "deleteProduct",id);
	}

}
