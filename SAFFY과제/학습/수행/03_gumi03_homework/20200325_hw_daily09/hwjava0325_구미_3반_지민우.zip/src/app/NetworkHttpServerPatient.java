package app;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import person.Patient;

public class NetworkHttpServerPatient {
	public static void main(String[] args)throws IOException {
		Patient p1 = new Patient("강호동", 42, "010-1111-1111", "호흡곤란", "001", true);
		Patient p2 = new Patient("홍길동", 30, "010-2222-2222", "과음", "901", false);
		Patient p3 = new Patient("김영미", 22, "010-3333-3333", "복통", "801", true);
		//환자 collection
		List<Patient> patientList = new ArrayList<Patient>();
		patientList.add(p1);
		patientList.add(p2);
		patientList.add(p3);
		
		
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body><h2>환자 정보</h2><table style='border: 1px solid green;'>");
		for (Patient p : patientList) {
			sb.append("<tr style='border: 1px solid green;'><td>").
			append("Name: ").append(p.getName().charAt(0)).append("XX").append("</td><td>").
			append(" Tel: ").append(p.getPhone().split("-")[0]).append("-").append(p.getPhone().split("-")[1]).append("-").append("XXXX").append("</td><td>").
			append(" Age: ").append(String.valueOf(p.getAge())).append("</td><td>").
			append(" Hospital: ").append(p.getHospitalId()).append("</td><td>").
			append(" 증상 : ").append(String.valueOf(p.getDiseaseName())).
			append(" COVID19 : ").append(String.valueOf(p.isCorona())).
			append("</td></tr>");
		}
		sb.append("</table></body></html>");
		String html = sb.toString();
		
		try (ServerSocket ss = new ServerSocket(8090)){
			System.out.println("HW0325");
			System.out.println("[WebServer is ready]");
			while(true) {
				try (Socket socket = ss.accept()){ // 병목현상 발생
					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),"UTF-8"));
					
					bw.write("HTTP/1.1 200 OK \r\n"); // 시작라인
					bw.write("Content-Type: text/html; charset=utf-8\r\n"); 
					bw.write("Content-Length: "+html.getBytes().length +"\r\n");
					bw.write("\r\n"); // 헤더
					bw.write(html);   // 바디 내용
					bw.write("\r\n");
					bw.flush();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
