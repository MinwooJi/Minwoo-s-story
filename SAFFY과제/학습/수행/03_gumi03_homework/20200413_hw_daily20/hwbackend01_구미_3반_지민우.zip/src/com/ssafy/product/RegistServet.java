package com.ssafy.product;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product/regist.do")
public class RegistServet extends HttpServlet {
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException,IOException{
		request.setCharacterEncoding("utf-8"); // 파라미터 한글처리
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String info = request.getParameter("info");
		
		StringBuilder html = new StringBuilder();
		html.append("<!DOCTYPE html>");
		html.append("<html>");
		html.append("	<head>");
		html.append("		<title>상품정보출력</title>");
		html.append("		<meta charset = 'utf-8'>");
		html.append("	</head>");
		html.append("	<body>");
		html.append("		<div>");
		html.append("			<h2>상품명 : " + name + "</h2>");
		html.append("		</div>");
		html.append("		<div>");
		html.append("			<h2>상품 가격 : " + price + "</h2>");
		html.append("		</div>");
		html.append("		<div>");
		html.append("			<h2>상품 정보 : " + info + "</h2>");
		html.append("		</div>");
		html.append("		<div>");
		html.append("			<a href='regist.html'>상품등록</a>");
		html.append("		</div>");
		html.append("	</body>");
		html.append("</html>");
		
		
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		out.print(html.toString());
		out.close();
	}
	
}
