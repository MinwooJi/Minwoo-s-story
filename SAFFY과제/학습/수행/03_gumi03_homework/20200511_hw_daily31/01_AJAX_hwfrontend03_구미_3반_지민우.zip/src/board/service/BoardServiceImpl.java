package board.service;
import java.util.List;

import board.dao.BoardDAO;
import board.dao.BoardDAOImpl;
import board.dto.Board;

public class BoardServiceImpl implements BoardService {
	private BoardDAO dao;
	public BoardServiceImpl() {
		dao = new BoardDAOImpl();
	}
	@Override
	public List<Board> list() throws Exception {
		return dao.selectBoard();
	}
	@Override
	public Board getBoard(int no) throws Exception {
		// TODO Auto-generated method stub
		return dao.selectByNo(no);
	}
	@Override
	public int insertBoard(Board board) throws Exception {
		// TODO Auto-generated method stub
		return dao.insertBoard(board);
	}
	@Override
	public int deleteBoard(int no) throws Exception {
		// TODO Auto-generated method stub
		return dao.deleteBoard(no);
	}

}