package board.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.Board;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/board/list")
public class BoardListController extends HttpServlet {
	private BoardService service = new BoardServiceImpl();
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=utf-8"); 
		System.out.println("list");
		try {
			List<Board> list = service.list();
			PrintWriter out = response.getWriter();
			out.println(new Gson().toJson(list));
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
	}
}
