package board.service;


import java.util.List;

import board.dto.Board;

public interface BoardService {
	List<Board> list() throws Exception;
	Board getBoard(int no) throws Exception;
	int insertBoard(Board board) throws Exception;
	int deleteBoard(int no) throws Exception;
}
