package board.dao;

import java.util.List;

import board.dto.Board;

public interface BoardDAO {
	List<Board> selectBoard() throws Exception;
	Board selectByNo(int no) throws Exception;
	int insertBoard(Board board) throws Exception;
	int deleteBoard(int no) throws Exception;
}
