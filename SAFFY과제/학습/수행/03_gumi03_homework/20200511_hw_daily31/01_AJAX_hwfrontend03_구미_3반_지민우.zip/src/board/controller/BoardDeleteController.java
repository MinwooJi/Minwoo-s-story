package board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.Board;
import board.service.BoardService;
import board.service.BoardServiceImpl;

@WebServlet("/board/delete")
public class BoardDeleteController extends HttpServlet {
	private BoardService service = new BoardServiceImpl();
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=utf-8"); 
		System.out.println("delete");
		int no = Integer.parseInt(request.getParameter("no"));
		int successCnt = 0;
		try {
			successCnt = service.deleteBoard(no);
		} catch (Exception e) {
			successCnt = -1;
			e.printStackTrace();
			throw new ServletException(e);
		}finally {
			PrintWriter out = response.getWriter();
			out.print(successCnt);
			out.close();
		}
	}
}
