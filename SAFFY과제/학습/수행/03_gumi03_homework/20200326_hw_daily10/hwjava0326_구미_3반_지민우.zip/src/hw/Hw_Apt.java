package hw;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Hw_Apt {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		File file = new File("./src/hw/AptDealHistory.xml");
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(file);
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("item");
			List<Apt>aptList = new ArrayList<>();
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					String name = element.getElementsByTagName("아파트").item(0).getTextContent();
					String location = element.getElementsByTagName("법정동").item(0).getTextContent();
					String price = element.getElementsByTagName("거래금액").item(0).getTextContent();
					aptList.add(new Apt(name, location, price));
				}
			}
			String temp = sc.next();
			for (Apt apt : aptList) {
				if(apt.getName().contains(temp)) {
					System.out.println(apt);
				}
			}
			
			
		}catch (SAXException | ParserConfigurationException | IOException e1) {
            e1.printStackTrace();
        }

	}
}
class Apt{
	String name;
	String location;
	String price;
	
	public Apt(String name, String location, String price) {
		this.name = name;
		this.location = location;
		this.price = price;
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Apt [name=" + name + ", location=" + location + ", price=" + price + "]";
	}
	
}