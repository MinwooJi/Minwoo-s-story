export default {
  template: `
    <div>
    <table class="table table-bordered w-50">
        <tr>
            <th>id</th>
            <td>{{emp.id}}</td>
        </tr>
        <tr>
            <th>name</th>
            <td>{{emp.cname}}</td>
        </tr>
        <tr>
            <th>email</th>
            <td>{{emp.mailid}}</td>
        </tr>
        <tr>
            <th>hiredate</th>
            <td>{{emp.start_date}}</td>
        </tr>
        <tr>
            <th>manager_id</th>
            <td>{{emp.manager_id}}</td>
        </tr>
        <tr>
            <th>title</th>
            <td>{{emp.title}}</td>
        </tr>
        <tr>
            <th>dept_name</th>
            <td>{{emp.dept_name}}</td>
        </tr>
        <tr>
            <th>salary</th>
            <td>{{emp.salary}}만원</td>
        </tr>
        <tr>
            <th>commission_pct</th>
            <td>{{emp.commission_pct}}</td>
        </tr>
        </table>
        <br />
        <div class="text-center">
            <router-link to="/list" class="btn btn-primary">목록</router-link>
            <router-link :to="'/update?id='+emp.id" class="btn btn-primary">수정</router-link>
            <router-link :to="'/delete?id='+emp.id" class="btn btn-primary">삭제</router-link>
        </div>
    </div>
    `,
  data() {
    return {
      emp: {},
    };
  },
  created() {
    const params = new URL(document.location).searchParams;
    axios
      .get(`http://localhost:8097/hrmboot/api/employee/${params.get('id')}`)
      .then(({ data }) => {
        console.dir(data);
        this.emp = data;
      })
      .catch((error) => {
        console.dir(error);
      });
  },
};
