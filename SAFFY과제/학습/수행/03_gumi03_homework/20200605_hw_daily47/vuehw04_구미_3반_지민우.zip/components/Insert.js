export default {
  template: `
    <div>
        <table class="table">
        <tr>
            <th>아이디</th>
            <td><input type="text" id="id" v-model="id" /></td>
        </tr>
        <tr>
            <th>이름</th>
            <td><input type="text" id="name" v-model="name" /></td>
        </tr>
        <tr>
            <th>이메일</th>
            <td><input type="text" id="mailid" v-model="mailid" /></td>
        </tr>
        <tr>
            <th>고용일</th>
            <td><input type="date" id="start_date" v-model="start_date" /></td>
        </tr>
        <tr>
            <th>관리자ID</th>
            <td><input type="text" id="manager_id" v-model="manager_id" /></td>
        </tr>
        <tr>
            <th>직책</th>
            <td>
            <select id="title" v-model="title">
                <option value="사장">사장</option>
                <option value="기획부장">기획부장</option>
                <option value="영업부장">영업부장</option>
                <option value="총무부장">총무부장</option>
                <option value="인사부장">인사부장</option>
                <option value="과장">과장</option>
                <option value="영업대표이사">영업대표이사</option>
                <option value="사원" selected>사원</option>
            </select>
            </td>
        </tr>
        <tr>
            <th>부서번호</th>
            <td><input type="text" id="dept_id" v-model="dept_id" /></td>
        </tr>
        <tr>
            <th>연봉</th>
            <td><input type="text" id="salary" v-model="salary" /></td>
        </tr>
        <tr>
            <th>커미션</th>
            <td><input type="text" id="commission_pct" v-model="commission_pct" /></td>
        </tr>
        </table>
        <div class="text-right">
        <button class="btn btn-primary" @click="checkHandler">등록</button>
        <button class="btn btn-primary" @click="moveList">목록</button>
        </div>
    </div>
    `,
  data() {
    // data는 가져올떄 함수형(return으로 가져와야한다.)
    // 목록 데이터 저장을 위한 배열 선언(배열의 이름 : items)
    return {
      id: '',
      name: '',
      mailid: '',
      start_date: '',
      manager_id: '',
      title: '',
      dept_id: '',
      salary: '',
      commission_pct: '',
      error: '',
    };
  },
  methods: {
    checkHandler() {
      let err = true;
      let msg = '';
      !this.name && ((msg = '이름을 입력해주세요'), (err = false));
      err && !this.mailid && ((msg = '이메일을 입력해주세요'), (err = false));
      err && !this.start_date && ((msg = '고용일을 입력해주세요'), (err = false));
      err && !this.manager_id && ((msg = '관리자를 입력해주세요'), (err = false));
      err && !this.title && ((msg = '직책을 입력해주세요'), (err = false));
      err && !this.dept_id && ((msg = '부서번호를 입력해주세요'), (err = false));
      err && !this.salary && ((msg = '월급을 입력해주세요'), (err = false));
      err && !this.commission_pct && ((msg = '커미션을 입력해주세요'), (err = false));
      if (!err) alert(msg);
      else {
        this.createHandler();
      }
    },
    moveList() {
      this.$router.push('/list');
    },
    createHandler() {
      axios
        .post('http://localhost:8097/hrmboot/api/employee', {
          id: this.id,
          name: this.name,
          mailid: this.mailid,
          start_date: this.start_date,
          manager_id: this.manager_id,
          title: this.title,
          dept_id: this.dept_id,
          salary: this.salary,
          commission_pct: this.commission_pct,
        })
        .then((response) => {
          if (response.data === 'success') {
            alert('등록이 완료되었습니다.');
          } else {
            alert('등록 처리시 문제가 발생했습니다.');
          }
          this.moveList();
        })
        .catch((error) => {
          this.error = error;
        });
    },
  },
};
