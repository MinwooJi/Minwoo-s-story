export default {
  template: `
  <div>
    <div>
        <input type="text" id="name" v-model="name" />
        <button class="btn btn-primary" @click="findEmp">검색</button>
    </div>
    <div v-if="empls.length">
        <table class="table table-bordered table-condensed">
        <colgroup>
            <col :style="{width: '10%'}" />
            <col :style="{width: '50%'}" />
            <col :style="{width: '15%'}" />
            <col :style="{width: '25%'}" />
        </colgroup>
        <tr>
            <th>사원 아이디</th>
            <th>사원명</th>
            <th>부서</th>
            <th>직책</th>
            <th>연봉</th>
        </tr>
        <tr v-for="emp in empls">
            <td>{{emp.id}}</td>
           
            <td><router-link :to="'/detail?id='+emp.id">{{emp.name}}</router-link></td>
            <td>{{emp.dept_name}}</td>
            <td>{{emp.title}}</td>
            <td>{{emp.salary}}만원</td>
        </tr>
        </table>
    </div>
    <div v-else class="text-center">
        등록 된 사원이 없습니다.
    </div>
    <div class="text-right">
        <button class="btn btn-primary" @click="moveToInsert">사원등록</button>
    </div>
</div>
    `,
  data() {
    return {
      name: '',
      empls: [],
    };
  },

  created: function () {
    axios
      .get('http://localhost:8097/hrmboot/api/employee/all')
      .then(({ data }) => {
        console.dir(data);
        this.empls = data;
      })
      .catch((error) => {
        console.dir(error);
      });
  },
  methods: {
    moveToInsert() {
      this.$router.push('/insert');
    },
    findEmp() {
      // const emps = JSON.parse(localStorage.getItem('ssafyemp'));
      let newEmps = [];
      if (this.name) {
        if (this.empls.length == 0) {
          alert('회원정보가 없습니다.');
        } else {
          for (let emp of this.empls) {
            if (emp.name.includes(this.name)) newEmps.push(emp);
          }
          //this.empls = [];
          this.empls = newEmps;
        }
      } else {
        alert('검색할 이름을 입력하세요');
      }
    },
  },
};
