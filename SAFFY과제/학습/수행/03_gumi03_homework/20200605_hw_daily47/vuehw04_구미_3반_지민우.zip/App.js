import Delete from './components/Delete.js';
import Detail from './components/Detail.js';
import Index from './components/Index.js';
import Insert from './components/Insert.js';
import List from './components/List.js';
import Update from './components/Update.js';
export default new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/',
      component: Index,
    },
    {
      path: '/delete',
      component: Delete,
    },
    {
      path: '/detail',
      component: Detail,
    },
    {
      path: '/insert',
      component: Insert,
    },
    {
      path: '/list',
      component: List,
    },
    {
      path: '/update',
      component: Update,
    },
  ],
});
