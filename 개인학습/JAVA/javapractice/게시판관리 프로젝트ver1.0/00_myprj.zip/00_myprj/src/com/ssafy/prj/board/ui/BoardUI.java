/*
 * vo = valueObject
 * daO = 
 */
package com.ssafy.prj.board.ui;

import java.util.Scanner;

import com.ssafy.prj.board.dao.BoardDAO;
import com.ssafy.prj.board.vo.Board;
import com.ssafy.prj.util.List;

public class BoardUI{

	private Scanner sc;
	private BoardDAO dao = new BoardDAO();

	public void service() {
		sc = new Scanner(System.in);
		System.out.println("게시판 관리 프로그램");
		for (;;) {
			BaseUI ui = null;
			switch (menu()) {
			case 1: ui = new ListBoardUI(dao);break;
			case 2: ui = new DetailBoardUI(dao);break;
			case 3: ui = new WriteBoardUI(dao);break;
			case 4: ui = new UpdateBoardUI(dao);break;
			case 5: ui = new DeleteBoardUI(dao);break;
			case 0:
				exitBoard();
				break;
			}
			if(ui != null) {
				ui.service();
			}
		}
	}
	/**
	 * @return
	 */
	private int menu() {
		System.out.println("------------------------");
		System.out.println("1. 전체 조회");
		System.out.println("2. 글번호 조회");
		System.out.println("3. 등록");
		System.out.println("4. 수정");
		System.out.println("5. 삭제");
		System.out.println("0. 종료");
		System.out.println("------------------------");
		System.out.print("메뉴 : ");
		return Integer.parseInt(sc.nextLine());
	}
	private void exitBoard() {
		System.out.println("게시글 관리프로그램을 종료합니다.");
		System.exit(0);
	}
	/**
	 * @param sc
	 */

}
