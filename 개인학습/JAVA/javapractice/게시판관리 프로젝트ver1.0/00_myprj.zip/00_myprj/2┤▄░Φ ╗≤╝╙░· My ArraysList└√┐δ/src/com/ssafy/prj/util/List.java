package com.ssafy.prj.util;

import java.util.Arrays;

public class List {
	// 데이터 꺼내기
	public Object get(int index){return null;}
	// 데이터 추가
	public void add(Object obj) {}
	public void add(int index,Object obj) {}
	// 크기
	public int size() {return 0;}
	// 데이터 삭제
	public Object remove(int index) {return null;}
	public void remove(Object obj) {}
	// 데이터 존재 여부
	public void clear() { }
	public boolean isEmpty() {return false;} 
	
	
}
