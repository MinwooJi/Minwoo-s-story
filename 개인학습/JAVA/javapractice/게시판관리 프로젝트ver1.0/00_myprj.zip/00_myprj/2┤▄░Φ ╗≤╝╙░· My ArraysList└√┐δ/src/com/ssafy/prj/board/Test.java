/*
 *  1. 전체조회
 *  2. 조회
 *  3. 등록
 *   ...
 *  MVC구조
 *  
 */
package com.ssafy.prj.board;

import com.ssafy.prj.board.ui.BoardUI;

public class Test {

	public static void main(String[] args) {
		new BoardUI().service(); //게시판 프로그램 화면 호출
	}

}
