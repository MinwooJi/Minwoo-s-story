package com.ssafy.prj.board.dao;
//insert
//delete
//selectBoard

import com.ssafy.prj.board.vo.Board;
import com.ssafy.prj.util.ArrayList;
import com.ssafy.prj.util.List;

public class BoardDAO { // Data Access Object
	List list = new ArrayList();
	private int boardNo = 0;
	
	public List selectBoard() {
		return list;
	}

	public Board selectOneBoard(int no) {
		for(int i = 0; i< list.size(); i++) {
			Board board = (Board)list.get(i);
			if(board.getNo() == no) {
				board.setViewCnt(board.getViewCnt()+1);
				return board;
			}
		}
		return null;
	}

	public void insertBoard(Board board) {
		// 용량이 꽉찼음 - 증가시키자
//			Board[] tmp = new Board[pos*2];
//			System.arraycopy(list, 0, tmp, 0, pos);
//			list = tmp;
//			위의 코드를 한줄로 줄임
		board.setNo(++boardNo);
		list.add(board);
	}

	public void deleteBoard(int no) {
		for(int i = 0; i<list.size();i++) {
			Board board = (Board)list.get(i);
			if (board.getNo() == no) {
				list.remove(i);
				return;
			}
		}
	}

	public	void updateBoard(Board board){	
		for(int i = 0; i<list.size();i++) {
			Board b = (Board)list.get(i);
			if (b.getNo() == board.getNo()) {
				b.setTitle(board.getTitle());
				b.setContent(board.getContent());
				return;
			}
		}
	
	}
}
