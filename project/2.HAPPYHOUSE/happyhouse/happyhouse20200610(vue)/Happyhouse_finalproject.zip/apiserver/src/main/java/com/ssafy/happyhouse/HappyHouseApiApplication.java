package com.ssafy.happyhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyHouseApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyHouseApiApplication.class, args);
	}

}
