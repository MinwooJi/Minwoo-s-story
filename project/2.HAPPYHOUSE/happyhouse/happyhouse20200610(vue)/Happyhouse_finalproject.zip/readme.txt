
apiserver는 vue와 db간의 통신을 위해 만들었으며 용량문제로 src폴더만 첨부하였습니다.

HappyHouse_Web_Front_Gumi_3ban_NoWooHyun_JiMinWoo 프로젝트는 

이전 관통프로젝트에 이번 vue로 만든 QnA게시판을
npm run build 를 사용하여 가져와서 jsp로 만들었고 새로 추가된 qna에 대한 화면캡처도 
프로젝트내 산출물 폴더에 첨부되어있습니다.