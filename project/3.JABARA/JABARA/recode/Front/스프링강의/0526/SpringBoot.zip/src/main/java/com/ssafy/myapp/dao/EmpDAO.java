package com.ssafy.myapp.dao;

import java.util.List;

public interface EmpDAO {
   public List<String> selectAll();
}
