package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.UserInfo;
import com.ssafy.model.repository.UserRepository;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;

	public UserServiceImpl(UserRepository repo) {
		userRepo = repo;
	}

	@Override
	public UserInfo login(String id, String pass) {
		return userRepo.select(id);
	}

	@Override
	public UserInfo select(String id) {
		return userRepo.select(id);
	}

	@Override
	public List<UserInfo> selectAll() {
		return userRepo.selectAllUsers();
	}

	@Override
	public int joinDayTime(UserInfo info) {
		return userRepo.insert(info);
	}

	@Override
	public int updateDayTime(UserInfo info) {
		return userRepo.update(info);
	}

	@Override
	public int leaveDayTime(String id) {
		return userRepo.delete(id);
	}

	@Override
	public UserRepository getUserRepo() {
		return userRepo;
	}

}
