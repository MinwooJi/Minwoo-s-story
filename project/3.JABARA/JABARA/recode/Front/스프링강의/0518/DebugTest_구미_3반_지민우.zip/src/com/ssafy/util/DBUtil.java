package com.ssafy.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.model.Member;
import com.ssafy.model.Product;

public class DBUtil {

	private static Map<String,Member> memberMap;
	private static Map<String,Product> productMap;
	
	
	public DBUtil() {
	   memberMap=new HashMap<>();
	   productMap=new HashMap<>();
	  
	   //######################## 기본 데이터 입력 #################################
	   memberMap.put("admin", new Member("admin", "admin", "admin", "admin",
			     "admin@ssafy.com","www.ssafy.com","seoul",new String[] {"독서"})) ;
	   memberMap.put("ssafy", new Member("ssafy", "ssafy", "ssafy", "ssafy",
			     "java@ssafy.com","www.ssafy.com","seoul",new String[] {"독서","여행"})) ;
	   
	   productMap.put("NT950SBE", new Product("NT950SBE","노트북Pen S","노트북",
	         "2019.1.1","삼성",2660000,"극강의 퍼포먼스, 혁신의 S펜"));
	   productMap.put("NT930XBE", new Product("NT930XBE","노트북9 Always","노트북",
		         "2019.5.5","삼성",1760000,"충전은 빠르게 사용은 여유롭게"));
	
	}
	
	//######################## Member관련 CRUD ########################
	public Member selectLogin(String id){
		return memberMap.get(id);
	}
	
	public void addMember(Member member) throws Exception{
	    if(memberMap.get(member.getId()) != null)
		    throw new Exception("중복된 아이디가 존재합니다.");
		memberMap.put(member.getId(), member);
	}

	//######################## Product관련 CRUD ########################
	public void addProduct(Product product) throws Exception{
		if(productMap.get(product.getNum())!=null)
		    throw new Exception("중복된 상품이 존재합니다.");
		productMap.put(product.getNum(), product);
	}
	
	public List<Product> selectProductAll() {
		return toList(productMap);
	}
	
	public List<Product> selectProductByTitle(String title) {
		return toListByTitle(productMap,title);
	}
	
	public List<Product> selectProductByCategory(String category) {
		return toListByCategory(productMap, category);
	}
	
	public List<Product> selectProductPrice(int price) {
		return toListByPrice(productMap, price);
	}

	public Product selectProduct(String num) {
		return productMap.get(num);
	}
	
    public void updateProduct(String num, int price) {
    	productMap.get(num).setPrice(price);
    }
    
    public void deleteProduct(String num) {
    	productMap.remove(num);
    }
	
	
	//######################## Map ==> List변환 ########################	
    private List<Product> toList(Map<String,Product> map){
    	List<Product> list = new ArrayList<>();
    	for(String key: map.keySet()) {
    	    list.add(map.get(key));
    	}
    	return list;
    }
    
    private List<Product> toListByTitle(Map<String,Product> map, String title){
    	List<Product> list = new ArrayList<>();
    	Product product=null;
    	for(String key: map.keySet()) {
    		product = map.get(key);
    		if(product.getTitle().contains(title)) 
    			list.add(product);
    	}
    	return list;
    }
    
    private List<Product> toListByCategory(Map<String,Product> map, String category){
    	List<Product> list = new ArrayList<>();
    	Product product=null;
    	for(String key: map.keySet()) {
    		product = map.get(key);
    		
    			list.add(product);
    	}
    	return list;
    }
    
    private List<Product> toListByPrice(Map<String,Product> map, int price){
    	List<Product> list = new ArrayList<>();
    	Product product=null;
    	for(String key: map.keySet()) {
    		product = map.get(key);
    		if(product.getPrice() <= price) 
    			list.add(product);
    	}
    	return list;
    }
    
}







