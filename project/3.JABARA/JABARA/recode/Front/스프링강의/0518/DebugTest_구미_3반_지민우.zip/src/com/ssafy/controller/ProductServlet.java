package com.ssafy.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.IProductDAO;
import com.ssafy.model.Product;
import com.ssafy.model.ProductDAOImpl;



public class ProductServlet extends HttpServlet {

	private IProductDAO dao = new ProductDAOImpl();
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		process(req, res);
	}
	public void process(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		req.setCharacterEncoding("utf-8");
		String action = req.getParameter("action");
		System.out.println("action:"+action);
		if (action.equals("SAVE")) {
			save(req, res);
		} else if (action.equals("VIEW")) {
			view(req, res);
		}else if (action.equals("DEL")) {
			delete(req, res);
		}else if (action.equals("SEARCH")) {
			search(req, res);
		}else if (action.equals("REGPRODUCT")) {
			req.getRequestDispatcher("/product/Product.jsp").forward(req, res);
		}else if (action.equals("DESC")) {
			desc(req, res);
		}
	}// process()
	public void desc(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String num = req.getParameter("num");
		System.out.println("!!!");
		System.out.println("!"+num);
		String nextPage="Error.jsp";
		Product b;
		try {
			b = dao.search(num);
			req.setAttribute("result", b.getDescription());
			nextPage="DescResult.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("msg","오류 발생,  다시 시도해 주세요.");
		}
		req.getRequestDispatcher(nextPage).forward(req, res);
	}
	public void search(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String nextPage="Error.jsp";
		String field = req.getParameter("searchField");
		if(field == null) field="";
		String text = req.getParameter("searchText");
		if(text == null)  text="";
		field=field.trim();
		text=text.trim();
		System.out.println(field+":"+text);
		List<Product> result=null;
		try {
			switch(field){
			case "TITLE":			
					result=dao.searchByTitle(text);				
				break;
			case "CATEGORY":
				result=dao.searchByCategory(text);
				break;
			case "PRICE":
				result=dao.searchByPrice(Integer.parseInt(text));
				break;
			default :
				result=dao.search();
			}
			req.setAttribute("result", result );
			req.setAttribute("field", field );
			req.setAttribute("text", text );
			req.setAttribute("pros", result );
			nextPage="/product/ProductList.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("msg","검색 중 오류가 발생했습니다." );
		}
		req.getRequestDispatcher(nextPage).forward(req, res);
	}
	
	public void view(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String nextPage="Error.jsp";
		String num = req.getParameter("num").trim();
		System.out.println(num);
		try {
			req.setAttribute("b",dao.search(num) );
			nextPage="product/ProductView.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("msg","검색 중 오류가 발생했습니다." );
		}
		req.getRequestDispatcher(nextPage).forward(req, res);
	}
	public void delete(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String num = req.getParameter("num").trim();
		String nextPage="Result.jsp";
		try {
			req.setAttribute("msg", "정상적으로 삭제 되었습니다");
			dao.delete(num);
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("msg", e.getMessage());
			nextPage="Error.jsp";
		}
		req.getRequestDispatcher(nextPage).forward(req, res);
	}
	public void save(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {

		String num = req.getParameter("num").trim();
		String title = req.getParameter("title").trim();
		String category = req.getParameter("category").trim();
		String pdate = req.getParameter("pdate").trim();
		String vendor = req.getParameter("vendor").trim();
		String price = req.getParameter("price").trim();
		int p = Integer.parseInt(price);
		String description = req.getParameter("description").trim();
		Product pro = new Product(num, title, category, pdate,	vendor,  p,  description);
		System.out.println(pro);
 		String nextPage="Result.jsp";
		try {
			dao.insertProduct(pro);
			req.setAttribute("Product", pro);
			req.setAttribute("msg", "정상적으로 저장 되었습니다");
		} catch (Exception e) {
			e.printStackTrace();
			
			
			nextPage="Error.jsp";		
		}
		req.getRequestDispatcher(nextPage).forward(req, res);
	}
	
	
}