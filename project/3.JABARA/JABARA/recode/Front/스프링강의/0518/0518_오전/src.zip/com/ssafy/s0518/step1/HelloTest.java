package com.ssafy.s0518.step1;

public class HelloTest {
   public static void main(String[] args) {
	    MessageBean msg = new MessageBean();
	      msg.sayHello("홍길동");
   }
}
