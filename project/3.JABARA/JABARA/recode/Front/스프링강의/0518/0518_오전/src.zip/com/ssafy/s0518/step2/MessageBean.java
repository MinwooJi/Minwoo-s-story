package com.ssafy.s0518.step2;

public interface MessageBean {//연결객체
   public void sayHello(String name);//선언된 메소드
}
