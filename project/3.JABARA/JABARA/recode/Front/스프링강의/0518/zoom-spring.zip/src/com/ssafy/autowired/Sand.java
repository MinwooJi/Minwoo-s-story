package com.ssafy.autowired;

public interface Sand {
	void info();
}
