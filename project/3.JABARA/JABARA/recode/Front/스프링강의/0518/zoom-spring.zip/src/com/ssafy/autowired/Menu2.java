package com.ssafy.autowired;

public class Menu2 {
	private Sand sand;
	public void setSand(Sand sand) {
		System.out.println("set sand");
		this.sand = sand;
	}
	
}
