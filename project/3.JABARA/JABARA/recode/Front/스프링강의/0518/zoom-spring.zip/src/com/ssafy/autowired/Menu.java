package com.ssafy.autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Menu {
//	@Qualifier("hamSand"); 이름이 여러개일때 선택해서 autowired할떄 보통의 경우 안씀
	@Autowired // 변수,생성자,set메서드 사용가능
	private Sand sand;
	public void print() {
		if(sand == null) {
			System.out.println("샌드위치 없음");
		}else {
			sand.info();
		}
	}
	
}
