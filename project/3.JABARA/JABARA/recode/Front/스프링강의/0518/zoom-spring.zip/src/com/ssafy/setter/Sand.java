package com.ssafy.setter;

public interface Sand {
	void info();
}
