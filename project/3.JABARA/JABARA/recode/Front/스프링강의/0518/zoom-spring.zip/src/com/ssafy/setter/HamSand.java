package com.ssafy.setter;

public class HamSand implements Sand {
	public HamSand() {
		System.out.println("햄 생성자");
	}
	@Override
	public void info() {
		System.out.println("햄 샌드위치입니다.");
	}
}
