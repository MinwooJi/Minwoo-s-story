package com.ssafy.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext container = new GenericXmlApplicationContext(
				"applicationContext.xml"
		);
		System.out.println("컨테이너 로딩 종료");
		
		Sand sand1 = (Sand)container.getBean("hamSand");
		sand1.info();
	}
}
