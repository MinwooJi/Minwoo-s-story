package com.ssafy.setter;

public class Menu {
	private Sand sand;
	public Menu(Sand sand) {
		this.sand = sand;
		System.out.println("메뉴생성자");
		
	}
	
}
