package com.ssafy.model;

import java.util.List;

import com.ssafy.util.DBUtil;


public class ProductDAOImpl implements IProductDAO {
    DBUtil db;
	
	public ProductDAOImpl() {
	   db = new DBUtil();
	}
	
	@Override
	public void insertProduct(Product product) throws Exception{		
        db.addProduct(product);
	}
	
	@Override
	public List<Product> search() throws Exception{
        return db.selectProductAll();
	}

	@Override
	public List<Product> searchByTitle(String title) throws Exception{
        
        return db.selectProductByTitle(title);
	}

	@Override
	public List<Product> searchByCategory(String category) throws Exception{
        
        return db.selectProductByCategory(category);
	}

	@Override
	public List<Product> searchByPrice(int price) throws Exception{
        
        return db.selectProductPrice(price);
	}

	@Override
	public Product search(String num) throws Exception{
       
        return db.selectProduct(num);
	}

	@Override
	public void update(String num, int price) throws Exception{
        db.updateProduct(num, price);
	}

	@Override
	public void delete(String num) throws Exception{
        db.deleteProduct(num);
	}
}
