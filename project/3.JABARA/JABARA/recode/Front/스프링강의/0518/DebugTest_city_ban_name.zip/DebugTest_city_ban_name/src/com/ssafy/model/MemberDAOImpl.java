package com.ssafy.model;

import com.ssafy.util.DBUtil;

public class MemberDAOImpl implements IMemberDAO {

	DBUtil db;
	
	public MemberDAOImpl() {
	   db = new DBUtil();
	}
	
	@Override
	public boolean  loginCheck(String user, String pass) throws Exception{
		
		Member member = db.selectLogin(user);
		
		if(member!=null) {
			if(member.getPw().equals(pass))
				return true;
		}
		return false;
	}

	@Override
	public void add(Member m) throws Exception{
		db.addMember(m);
	}
	
}







