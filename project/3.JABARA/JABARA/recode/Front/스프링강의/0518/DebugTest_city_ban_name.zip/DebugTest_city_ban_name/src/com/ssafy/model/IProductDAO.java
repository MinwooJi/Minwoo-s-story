package com.ssafy.model;

import java.util.List;

public interface IProductDAO {

	void insertProduct(Product product) throws Exception;

	List<Product> search() throws Exception;

	List<Product> searchByTitle(String title) throws Exception;

	List<Product> searchByCategory(String category) throws Exception;

	List<Product> searchByPrice(int price) throws Exception;

	Product search(String num) throws Exception;

	void update(String num, int price) throws Exception;

	void delete(String num) throws Exception;

}