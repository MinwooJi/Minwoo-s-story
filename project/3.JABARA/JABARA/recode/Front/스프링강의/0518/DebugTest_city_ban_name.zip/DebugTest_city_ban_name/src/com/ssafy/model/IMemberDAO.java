package com.ssafy.model;

public interface IMemberDAO {

	boolean loginCheck(String user, String pass) throws Exception;

	void add(Member m) throws Exception;

}