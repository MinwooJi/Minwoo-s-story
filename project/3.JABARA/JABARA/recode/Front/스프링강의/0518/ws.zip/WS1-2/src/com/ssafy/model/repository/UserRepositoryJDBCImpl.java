package com.ssafy.model.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.UserInfo;

@Repository("userRepository")
public class UserRepositoryJDBCImpl implements UserRepository {

	@Override
	public List<UserInfo> selectAllUsers() {
		System.out.println("User전체조회성공~!!");
		return null;
	}

	@Override
	public UserInfo select(String id) {
		System.out.println("User조회성공~!!");
		return null;
	}

	@Override
	public int insert(UserInfo info) {
		System.out.println("User추가성공~!!");
		return 0;
	}

	@Override
	public int update(UserInfo info) {
		System.out.println("User수정성공~!!");
		return 0;
	}

	@Override
	public int delete(String userId) {
		System.out.println("User삭제성공~!!");
		return 0;
	}
}
