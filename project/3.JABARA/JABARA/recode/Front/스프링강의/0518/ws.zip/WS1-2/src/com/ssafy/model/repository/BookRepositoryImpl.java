package com.ssafy.model.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Book;

@Repository("bookRepository")
public class BookRepositoryImpl implements BookRepository {

	@Override
	public int insert(Book book) {
		System.out.println("Book등록성공~!!");
		return 0;
	}

	@Override
	public int update(Book book) {
		System.out.println("Book수정성공~!!");
		return 0;
	}

	@Override
	public int delete(String isbn) {
		System.out.println("Book삭제성공~!!");
		return 0;
	}

	@Override
	public Book select(String isbn) {
		System.out.println("Book조회성공~!!");
		return null;
	}

	@Override
	public List<Book> selectAll() {
		System.out.println("Book전체조회성공~!!");
		return null;
	}
}
