package com.ssafy.test;

import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.ssafy.model.dto.Book;
import com.ssafy.model.dto.UserInfo;
import com.ssafy.model.service.BookService;
import com.ssafy.model.service.UserService;

public class BeanTest {
	
	BookService bookService;
	UserService userService;	

	public BeanTest() {
		GenericApplicationContext container = new GenericXmlApplicationContext(
				"applicationContext.xml"
		); 
		bookService = (BookService)container.getBean("bookService");
		userService = (UserService)container.getBean("userService");
		
		container.close();
	}

	
	public void testBookRepo() {		
        bookService.insert(new Book());
        bookService.update(new Book());
        bookService.delete("삭제isbn");
        bookService.select("조회isbn");
        bookService.selectAll();
	}
	
	public void testUserRepo() {
		System.out.println("=====================");
		userService.joinDayTime(new UserInfo());
		userService.updateDayTime(new UserInfo());
		userService.leaveDayTime("탈퇴아이디");
		userService.select("조회아이디");
		userService.selectAll();
	}
	
	public static void main(String[] args) {
		BeanTest test = new BeanTest();
		test.testBookRepo();
		test.testUserRepo();
	}
}
