package com.ssafy.day3.service;

import com.ssafy.day3.dto.Guest;

public class GuestServiceImpl implements GuestService{

	@Override
	public void registry(Guest guest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modify(Guest guest) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void find(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void findAll() {
		// TODO Auto-generated method stub
		
	}

}
