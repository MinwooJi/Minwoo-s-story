package org.springframework.web.servlet;

public interface Controller {
	public void 
}
