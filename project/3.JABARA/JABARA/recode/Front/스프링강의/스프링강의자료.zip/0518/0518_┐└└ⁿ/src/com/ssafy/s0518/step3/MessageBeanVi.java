package com.ssafy.s0518.step3;

public class MessageBeanVi implements MessageBean{

	@Override
	public void sayHello(String name) {
	   System.out.println("신짜오, "+name+"!!");
	}

}
