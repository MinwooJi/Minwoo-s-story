package com.ssafy.s0518.step4.di;

public interface MessageBean {
     public void sayHello();
}
