package com.ssafy.s0518.step3;

public class MessageBeanEn implements MessageBean {

	@Override
	public void sayHello(String name) {
	   System.out.println("Hello, "+name+"!!");   	
	}

}
