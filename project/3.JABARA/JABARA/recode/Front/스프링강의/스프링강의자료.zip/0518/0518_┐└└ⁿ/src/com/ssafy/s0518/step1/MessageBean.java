package com.ssafy.s0518.step1;

public class MessageBean {
   
	public void sayHello(String name) {
//		System.out.println("안녕, "+ name);
//		System.out.println("Hello, "+ name);
		System.out.println("신짜오, "+ name);
	}
}
