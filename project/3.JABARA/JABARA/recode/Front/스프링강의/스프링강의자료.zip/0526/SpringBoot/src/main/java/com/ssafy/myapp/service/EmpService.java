package com.ssafy.myapp.service;

import java.util.List;

public interface EmpService{
    public List<String> findName();
}
