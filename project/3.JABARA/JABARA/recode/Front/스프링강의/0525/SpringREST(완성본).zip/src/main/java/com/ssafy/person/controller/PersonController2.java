package com.ssafy.person.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.person.dto.Person;
import com.ssafy.person.service.PersonService;


//Ajax요청의 응답 전용 컨트롤러!!
@RestController //나 컨트롤러!! ---> servlet-context.xml등록
//@RequestMapping("/rest")
public class PersonController2 {
	
	@Autowired
	PersonService service;

	//@RequestMapping(value = "/all" ,method = RequestMethod.GET )
	@GetMapping("/all")  
	public List<Person> list(Model m) {		
		return service.findAll();//JSP페이지 포워딩
	}//전체조회  :  http://localhost:8080/person/all   + GET
	
	
	@PostMapping("/")  
	public String regist(Person person) {	
		System.out.println("입력 사람>>>"+ person);		
		int  t=  service.registry(person);
		if(t==1) {
			return "success";
		}else {
			return "fail";
		}
	}//사람등록  :  http://localhost:8080/person   + POST
	
	
	@GetMapping("/{no}")  
	public Person list(@PathVariable("no") int no) {
		System.out.println("수정 번호>>>"+ no);
		return service.find(no);
	}//수정폼데이터 조회  :  http://localhost:8080/person/13   + GET
	
	@PutMapping("/")  
	public String modify(@RequestBody Person person) {
		System.out.println("수정 사람>>>"+ person);
		if(service.modify(person)==1) return "success";
		else return "fail";		
	}//사람수정  :  http://localhost:8080/person/3   + PUT
	
	
	@DeleteMapping("/{no}")  
	public String remove(@PathVariable("no") Integer no) {	
		if(service.remove(no)==1) return "success";
		else return "fail";		
	}//사람삭제  :  http://localhost:8080/person/3   + DELETE
	
}







